/*
 * Copyright (C) 2017 Willian Alves Lima
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package leitoresXML;

import java.util.jar.Attributes;
import jdk.internal.org.xml.sax.SAXException;
import jdk.internal.org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Willian Alves Lima
 */
public class LeitorSAX  extends DefaultHandler {

  @Override
  public void startDocument() throws SAXException {

  }
  
  public void startElement(String uri, String localName, 
        String name, Attributes attributes) throws SAXException {
  // aqui voce é avisado, por exemplo
  // do inicio da tag "<preco>"
  }
  
  @Override
  public void characters(char[] chars, int offset, int len) 
                throws SAXException {
    // aqui voce seria avisado do inicio
    // do conteudo que fica entre as tags, como por exemplo 30
    // de dentro de "<preco>30</preco>"
    
    // para saber o que fazer com esses dados, voce precisa antes ter
    // guardado em algum atributo qual era a negociação que estava
    // sendo percorrida
  }
  
  @Override
  public void endElement(String uri, String localName, String name)
                 throws SAXException {
  // aviso de fechamento de tag
  }
}

